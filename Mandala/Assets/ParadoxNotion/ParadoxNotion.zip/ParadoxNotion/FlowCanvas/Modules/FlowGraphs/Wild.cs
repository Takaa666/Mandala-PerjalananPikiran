﻿
namespace FlowCanvas
{
    ///<summary>A stub class to replicate open generics</summary>
    public class Wild { }
}