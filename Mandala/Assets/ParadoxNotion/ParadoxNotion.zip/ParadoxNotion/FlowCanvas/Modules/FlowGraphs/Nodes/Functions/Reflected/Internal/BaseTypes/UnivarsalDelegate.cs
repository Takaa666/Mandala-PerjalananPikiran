﻿namespace FlowCanvas.Nodes
{
    public delegate void UniversalDelegate(UniversalDelegateParam[] delegateParams);
}