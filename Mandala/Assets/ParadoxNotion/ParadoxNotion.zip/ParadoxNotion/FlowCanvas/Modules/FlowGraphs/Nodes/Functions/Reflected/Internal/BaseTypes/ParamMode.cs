﻿namespace FlowCanvas.Nodes
{
    public enum ParamMode
    {
        Undefined = 0,
        In = 1,
        Out = 2,
        Ref = 3,
        Instance = 4,
        Result = 6,
    }
}