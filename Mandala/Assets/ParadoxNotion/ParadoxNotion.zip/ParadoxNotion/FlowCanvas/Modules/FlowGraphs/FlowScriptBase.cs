﻿namespace FlowCanvas
{

    abstract public class FlowScriptBase : FlowGraph { }
}
