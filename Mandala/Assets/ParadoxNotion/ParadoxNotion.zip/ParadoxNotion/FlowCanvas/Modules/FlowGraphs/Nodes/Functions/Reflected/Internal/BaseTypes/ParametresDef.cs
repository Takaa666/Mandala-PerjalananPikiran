﻿using System.Collections.Generic;

namespace FlowCanvas.Nodes
{
    public struct ParametresDef
    {
        public List<ParamDef> paramDefinitions;
        public ParamDef instanceDef;
        public ParamDef resultDef;
    }
}